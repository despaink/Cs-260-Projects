package service;

import java.sql.SQLException;

public class FillService extends Service {
    public FillService() {
    }

    /**
     * @ param r request message
     * breaks the request into its parts: Authorization token, generations
     * checks if Authtoken has user using AuthorizationDAO
     * checks if user has a family tree deletes existing tree using UserDAO
     * generates new tree to the number of generations given using PersonDAO, EventDAO
     * @return the response
     **/
    //r = URI
    public String run( String myURI ){
        String message="";

        String delims="[/]";
        String[] Tokens = myURI.split(delims);

        System.out.println(Tokens.length);
        //note Tokens[0] is empty

        //for(int i=0;i<Tokens.length;i++){ System.out.println("'"+Tokens[i]+"'");}
        if(Tokens.length == 3)// default fill
        {
            try {
                message= myDatabase.fill(Tokens[2]);
            } catch (SQLException e) {
                e.printStackTrace();
                message ="{\"message\": \"an SQL error occurred.\"}";
            }

        }

        else if(Tokens.length == 4)// an input for generation num exists
        {
            try {

                if(Tokens[3].matches(".*\\d+.*") ){
                    System.out.println("entered if generations is an int");
                    message= myDatabase.fill(Tokens[2],Integer.parseInt(Tokens[3]));

                }
                else{
                    message ="{\"message\": \" in URI, generations is not a number.\"}";

                }
            } catch (SQLException e) {
                e.printStackTrace();
                message ="{\"message\": \"an SQL error occurred.\"}";
            }
        }

        else// bad uri
        {
            message ="{\"message\": \"Bad Request, improper number of tokens in URI.\"}";

        }


        try{
            myDatabase.closeConnection(true);
        }catch(SQLException e){ System.err.println(e.getMessage());}

return message;
    }
}
