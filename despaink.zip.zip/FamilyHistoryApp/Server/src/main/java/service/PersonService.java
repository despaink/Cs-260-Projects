package service;

import java.sql.SQLException;

import model.User;

public class PersonService extends  Service{
    public PersonService() {
    }

    /**
     * @ param r request message
     * breaks the request into its parts: AuthToken, and person ID
     * uses AuthorizationTokenDAO to confirm that AuthToken is valid
     * confirms that personID is valid using PersonDAO
     * confirms that user connected to the AuthToken can access the person using PersonDAO
     * @return the response
     **/
    public String run (String myURI,String Authtoken) {
        String message="";

        String delims="[/]";
        String[] Tokens = myURI.split(delims);

        System.out.println(Tokens.length);
        //note Tokens[0] is empty

        //for(int i=0;i<Tokens.length;i++){ System.out.println("'"+Tokens[i]+"'");}
        if(Tokens.length == 2)// default get all the persons
        {

                message= myDatabase.getPersons(Authtoken);


        }

        else if(Tokens.length == 3)// get a person whose id is tokens[2]
        {

                message = myDatabase.getPerson(Tokens[2],Authtoken);

        }

        else// bad uri
        {
            message ="{\"message\": \"Bad Request, improper number of tokens in URI.\"}";

        }


        try{
            myDatabase.closeConnection(true);
        }catch(SQLException e){ System.err.println(e.getMessage());}

        return message;
    }


}
