package service;

import java.sql.SQLException;

public class Service {

    public Service(){
        try{
            myDatabase = new doa.Database();
            //System.out.println("preparing to connect to local database file");
            myDatabase.openConnection();
            //System.out.println("created connection with database");

        }catch(SQLException e){ System.err.println(e.getMessage());}

    }
    protected doa.Database myDatabase;

    public String retrieveValue(String token){
    String value="";
    String[] myArray;
    String delim ="[:]";
    myArray = token.split(delim);


        value = myArray[1].replace(",","");
        value = value.replace("\"","");
    //System.out.println( value);


    return value;
}

public boolean checkForEmptyHeaders(String[]Tokens){
        for(int i= 0;i<Tokens.length;i++){
            if("".equals(Tokens[i])){return false;}
            System.out.println(Tokens[i]);

        }
System.out.println("returning no empty headers");
return true;
    }


}
