package service;

import com.google.gson.Gson;

import java.sql.SQLException;

import doa.databaseFile.LoginFile;
import doa.databaseFile.RegisterFile;
import jdk.nashorn.internal.parser.Token;

public class RegisterService extends Service {
    public RegisterService(){}
    /**
     * @ param r request message
     * breaks the request into its parts: username, email, password, first name, last name, gender
     * Using userDAO checks to see if username is taken
     * uses those parts to create a user
     * as part of creating a user, generates a family tree using fill and create person
     * @return the response
     **/
    private RegisterFile myRegister;

    public String run( String reqData )  {

        System.out.println("Running registerService");
        boolean validInput = true;
        String message="";

        String userName="";
        String email="";
        String password="";
        String firstName="";
        String lastName="";
        String gender ="";

        String delims="[\n]";
        String[] Tokens = reqData.split(delims);
        //for(int i=0;i<Tokens.length;i++){ System.out.println(Tokens[i]);}

        Gson gson = new Gson();

        myRegister = gson.fromJson(reqData,RegisterFile.class);
        System.out.println("preparing to show json data");
        System.out.println(myRegister.getUserName()+" "+myRegister.getPassword()+" "+ myRegister.getEmail()+" "+myRegister.getFirstName()+" "+ myRegister.getLastName()+" "+myRegister.getGender());

        /*
        if(Tokens.length!= 8){// number of headers + 2 for '{' '}'
            validInput = false;
            message ="{\"message\": \"Improper number of headers in the request.\"}";
            System.out.println(message);
            System.out.println(Tokens.length);
            return message;
        }
*/


        if(validInput){
            //System.out.println("valid number of headers");

            String[] values={myRegister.getUserName(),myRegister.getPassword(),myRegister.getEmail(),myRegister.getFirstName(),myRegister.getLastName(),myRegister.getGender()};

            if(!checkForEmptyHeaders(values)){
                message ="{\"message\": \"One or more headers in the request are empty.\"}";
                return message;
            }



            //System.out.println(userName);


            try{
                validInput = !(myDatabase.findUser(myRegister.getUserName()));
                System.out.println(validInput);
            }catch(SQLException e){ message = "threw and exception in find User"; System.out.println( message); return message;}
            //check if userName is not taken
        }
        if(validInput){
            System.out.println("user is not found");

            try{
                myDatabase.createUser(myRegister.getUserName(),myRegister.getPassword(),myRegister.getEmail(),myRegister.getFirstName(),myRegister.getLastName(),myRegister.getGender(),4);
            }catch(SQLException e){ e.printStackTrace();message= "exception in createUser database"; System.out.println( message); return message;}
            message="{\"authToken\": \""+myDatabase.getMyToken()+"\",\"userName\": \""+myDatabase.getMyUserName()+"\", \"personID\": \""+ myDatabase.getMyUserID()+"\" }";

        }
        else{ message= "{\"message\": \"Username already in the dataBase.\"}";}

        try{
            myDatabase.closeConnection(true);
        }catch(SQLException e){ System.err.println(e.getMessage());}

//System.out.println("in register Service message is: "+message);
        return message;
    }
}
