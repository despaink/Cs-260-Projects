package service;

import java.net.URLDecoder;
import java.sql.SQLException;

public class EventService extends Service {
    public EventService() {
    }

    /**
     * @ param r request message
     * breaks the request into its parts: authorization token, event ID
     * validates AuthToken using AuthorizationToken DAO
     * validates that eventID can be accessed by Authtoken using EventDAO
     * @return the response
     **/
    public String run (String myURI,String Authtoken) {
        String message="";

        //myURI =URLDecoder.decode(myURI, "UTF-8");

        String delims="[/]";
        //System.out.println(myURI);
        String[] Tokens = myURI.split(delims);

        //System.out.println(Tokens.length);
        //note Tokens[0] is empty

        //for(int i=0;i<Tokens.length;i++){ System.out.println("'"+Tokens[i]+"'");}
        if(Tokens.length == 2)// default get all the persons
        {

            message= myDatabase.getEvents(Authtoken);


        }

        else if(Tokens.length == 3)// get a person whose id is tokens[2]
        {
            System.out.println(Tokens[2]);
            Tokens[2].replace("%20"," ");
            message = myDatabase.getEvent(Tokens[2],Authtoken);


        }

        else// bad uri
        {
            message ="{\"message\": \"Bad Request, improper number of tokens in URI.\"}";

        }


        try{
            myDatabase.closeConnection(true);
        }catch(SQLException e){ System.err.println(e.getMessage());}

        return message;
    }}
