package service;

import com.google.gson.Gson;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.sql.SQLException;

import doa.databaseFile.DatabaseFile;
import doa.names.locations;

public class LoadService extends Service{
    public LoadService() {
        myFile = new DatabaseFile();
    }

    protected DatabaseFile myFile;

    /**
     * @ param r request message
     * clears the database using ClearService
     * breaks the request into its parts: users[],persons[],events[]
     * adds users, persons, and events to the data base using UserDAO, PersonDAO, and EventDAO
     * @return the response
     **/
    public String run( String reqData ){
        System.out.println("running loadService");
        String message = "";

        ClearService allClear = new ClearService();
        allClear.run("");

        Gson gson = new Gson();
        //System.out.println("Preparing gson");


        myFile = gson.fromJson(reqData, DatabaseFile.class);
        //System.out.println( "file size: "+myFile.getSize());

        //insert things from file into database

        myDatabase.loadUsers(myFile.users);
        myDatabase.loadPersons(myFile.persons);
        myDatabase.loadEvents(myFile.events);

        try {
            myDatabase.closeConnection(true);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        message ="{\"message\": \" Successfully added "+myFile.users.length+" users, "+myFile.persons.length+" persons, and "+myFile.events.length+" events to the database.\"}";


        return message;
    }
}
