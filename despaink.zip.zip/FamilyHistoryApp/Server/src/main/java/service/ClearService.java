package service;

import java.sql.SQLException;

import doa.Database;

public class ClearService extends Service {
    public ClearService() {

    }


    /**
     * @ param r request message
     * uses DAO's to clear each row in the database, leaves the empty tables alone
     * @return the response
     **/
    public String run( String r ){
        System.out.println("Running clearService");
        try{
            //System.out.println("entered try in clear service");
            if(myDatabase == null){ System.out.println("database is null");}

            myDatabase.createTables();
            //System.out.println("finished createTables");
            myDatabase.closeConnection(true);
        }catch(SQLException e){ System.err.println(e.getMessage()); r = "{ \"message\" : \"clear method failed.\"}";  return r;}

        r="{ \"message\": \"Clear Succeeded.\"}";

        return r;
    }
}
