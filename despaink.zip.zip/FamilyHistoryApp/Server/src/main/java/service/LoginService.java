package service;

import com.google.gson.Gson;

import java.sql.SQLException;

import doa.databaseFile.LoginFile;


public class LoginService extends Service {
    public LoginService() {
    }

    private LoginFile myLogin;

    /**
     * @ param r request message
     * breaks the request into its parts: username, password
     * checks if user is valid
     * Uses AuthorizationTokenDOA to generate an Authorization Token
     * @return the response which would include an Authorization Token
     **/
    public String run( String reqData ){
        System.out.println("Running loginService");
        boolean validInput = true;
        String message="";

        String userName="";
        String password="";

        String delims="[\n]";
        String[] Tokens = reqData.split(delims);
        //for(int i=0;i<Tokens.length;i++){ System.out.println(Tokens[i]);}

        Gson gson = new Gson();

        myLogin = gson.fromJson(reqData,LoginFile.class);
        System.out.println("preparing to show json data");
        System.out.println(myLogin.getUserName()+" "+myLogin.getPassword());
/*
        if(Tokens.length!= 4){// number of headers + 2 for '{' '}'
            validInput = false;
            message ="{\"message\": \"Improper number of headers in the request.\"}";
            System.out.println(message);
            System.out.println(Tokens.length);
            return message;
        }
*/


        if(validInput){
            //System.out.println("valid number of headers");

            String[] values={myLogin.getUserName(),myLogin.getPassword()};

            if(!checkForEmptyHeaders(values)){
                message ="{\"message\": \"One or more headers in the request are empty.\"}";
                return message;
            }



            //System.out.println(userName);


            try{
                validInput = (myDatabase.findUser(myLogin.getUserName()));
                //System.out.println(validInput);
            }catch(SQLException e){ message ="{\"message\": \"User not in the database\"}";  return message;}
            //check if userName is not taken
        }
        if(validInput){
            System.out.println("user is found: logging in");

            myDatabase.loginUser(myLogin.getUserName(),myLogin.getPassword());

            System.out.println(myDatabase.getMyUserName());



            message="{\"authToken\": \""+myDatabase.getMyToken()+"\",\"userName\": \""+myDatabase.getMyUserName()+"\", \"personID\": \""+ myDatabase.getMyUserID()+"\" }";

        }
        else{
            try{
                myDatabase.closeConnection(false);
            }catch(SQLException e){ System.err.println(e.getMessage());}

            message= "{\"message\": \"Username not in the dataBase.\"}";
            return message;
        }

        try{
            myDatabase.closeConnection(true);
        }catch(SQLException e){ System.err.println(e.getMessage());}

        if( (myDatabase.getMyUserName()) == null){
            message= "{\"message\": \"Invalid login credentials\"}";
        }
//System.out.println("in register Service message is: "+message);
        return message;
    }
}
