package doa.databaseFile;

public class RegisterFile {

    /*"userName":"username",
	"password":"password",
	"email":"email",
	"firstName":"firstname",
	"lastName":"lastname",
	 "gender":"m/f"*/
    private String userName;
    private String password;
    private String email;
    private String firstName;
    private String lastName;
    private String gender;

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getGender() {
        return gender;
    }
}
