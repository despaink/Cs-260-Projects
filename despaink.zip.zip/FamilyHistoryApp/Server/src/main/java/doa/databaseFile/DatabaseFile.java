package doa.databaseFile;

import doa.Database;
import model.*;

public class DatabaseFile {
    public DatabaseFile(){}

    public User[] users;
    public Person[] persons;
    public Event[] events;

    public int getSize(){
        int size =0;
        size += users.length+persons.length+events.length;

        return size;
    }
}
