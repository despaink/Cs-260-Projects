package doa.databaseFile;

import java.util.ArrayList;
import java.util.List;

import model.Person;

public class PersonFile {
    public PersonFile(){
        data = new ArrayList<Person>();
    }
    private List<Person> data;

    public List<Person> getData() {
        return data;
    }
    public int getSize(){
        return data.size();
    }
    public void addPerson(Person temp){
        data.add(temp);
       // System.out.println("person added");
    }
}
