package doa.databaseFile;

import java.util.ArrayList;

import model.Event;

public class EventFile {
    public EventFile(){ data = new ArrayList<>();}

    private ArrayList<Event> data;

    public void addEvent(Event event){


        data.add(event);
        System.out.println("event added");
    }
}
