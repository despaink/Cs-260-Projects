package doa;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;

import model.AuthorizationToken;
import model.Person;
import model.User;

public class AuthorizationTokenDAO {
    public AuthorizationTokenDAO() {
    }

    private Connection connection;
    private AuthorizationToken currToken;
    private UserDAO myUserDAO;




    public String getMyToken(){return currToken.getToken();}

    public UserDAO getMyUserDAO(){return myUserDAO;}
    /**
     * creates a new AuthToken for the given user and stores it in the table
     * @return the new AuthToken **/
    public void createToken(User user){
        currToken= new AuthorizationToken(user);
        try{
            insertToken(user);
        }catch(SQLException e){ e.printStackTrace();}
    }

    public void insertToken(User user) throws SQLException {

        try {
            Statement stmt = null;
            try {
                stmt = connection.createStatement();

                //                stmt.executeUpdate("drop table if exists users");
                //System.out.println("preparing to insert authToken");


//insert into member (name, email_address) values ('Ann', 'ann@cs.byu.edu');
                String SQL = "insert into authorizationTokens ( 'Token', 'Username') values (\'"+currToken.getToken()+ "\', \'" + user.getUserName()+"\')";

                stmt.executeUpdate(SQL);

            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            throw new SQLException("insertToken in AuthTokenDAO failed", e);
        }

    }

    public void setMyUserDAO( UserDAO curr){ myUserDAO = curr;}




    public void setConnection(Connection newConnection){ connection = newConnection;}

    //returns true if valid
    public boolean validateToken(String authToken){

        try {
            Statement stmt = null;
            ResultSet rs = null;
            boolean notFound = false;
            try {
                //System.out.println("preparing to execute sql");
                String sql ="select* from authorizationTokens where `Token`= '"+authToken+"' ";


                stmt = connection.createStatement();
                rs = stmt.executeQuery(sql);

                //System.out.println(rs.next());
                //returns true if found, false if  not



                System.out.println("query executed: "+sql);

String userName="";
                while(rs.next()){
                    //System.out.println("inside of authtoken DAO validatetoken");
                     userName = rs.getString("Username");

                    AuthorizationToken temp = new AuthorizationToken();
                    User tempUser = new User();
                    tempUser = myUserDAO.retrieveUser(userName);

                    //System.out.println(tempUser.getUserName());

                    temp= new AuthorizationToken( authToken, tempUser);

                    currToken=temp;

                    //System.out.println(currToken.getToken());

                    myUserDAO.setCurrUser(tempUser);

                    //System.out.println(myUserDAO.currUser.getUserName());



                }
                if(userName.isEmpty()){ System.out.println("userName is empty");return false;}


            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        System.out.println("AuthToken is valid");

        return true;
    }

}