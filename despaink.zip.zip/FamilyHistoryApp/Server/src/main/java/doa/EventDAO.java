package doa;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.TreeSet;
import java.util.UUID;

import model.Event;
import model.Person;
import model.User;

import doa.names.*;

public class EventDAO {
    public EventDAO() {
    }

    private Connection connection;
    private Event currEvent;

    private locations myLocations;


    /**
     * generate events for the person given
     **/
    public void createEvent(Person person,String type, String relevantYear, boolean isRoot){
        cities myLocation = new cities();
        Event inProgress = new Event();
        int relYear = Integer.parseInt(relevantYear);
        int year;

        switch (type) {
            case "birth":
                myLocation = myLocations.randomCity();
                year = relYear - 22;
                if(isRoot){year = relYear;}
                inProgress = new Event(UUID.randomUUID().toString(), person.getDescendant(), person.getPersonID(), myLocation.getLatitude(), myLocation.getLongitude(), myLocation.getCountry(), myLocation.getCity(), type, Integer.toString(year));
               insertEvent(inProgress);
                break;
            case "baptism":
                myLocation = myLocations.randomCity();

                year = relYear - 14;
               if(isRoot){year = relYear+8;}

                inProgress = new Event(UUID.randomUUID().toString(), person.getDescendant(), person.getPersonID(), myLocation.getLatitude(), myLocation.getLongitude(), myLocation.getCountry(), myLocation.getCity(), type, Integer.toString(year));
                insertEvent(inProgress);

                break;
            case "marriage":
                myLocation = myLocations.randomCity();

                year = relYear - 2;
                if(isRoot){year = relYear+22;}

                inProgress = new Event(UUID.randomUUID().toString(), person.getDescendant(), person.getPersonID(), myLocation.getLatitude(), myLocation.getLongitude(), myLocation.getCountry(), myLocation.getCity(), type, Integer.toString(year));
                insertEvent(inProgress);

                break;
            case "death":
                myLocation = myLocations.randomCity();

                year = relYear + 50;
                if(isRoot){year = relYear+72;}

                inProgress = new Event(UUID.randomUUID().toString(), person.getDescendant(), person.getPersonID(), myLocation.getLatitude(), myLocation.getLongitude(), myLocation.getCountry(), myLocation.getCity(), type, Integer.toString(year));
                insertEvent(inProgress);

                break;
            default:
                System.out.println("invalid type!!!");
                break;
        }



    }
    /**
     * selects for the event ID and retrieves it from the table
     * @return the event
     **/
    public Event retrieveEvent( String eventID){
        Event myEvent = new Event();
        try {
            Statement stmt = null;
            ResultSet rs = null;
            boolean notFound = true;
            try {
                //System.out.println("preparing to execute sql");
                String sql ="select* from events where `Event ID`= '"+eventID+"' ";


                stmt = connection.createStatement();
                rs = stmt.executeQuery(sql);

                //System.out.println(rs.next());
                //returns true if found, false if  not



                System.out.println("query executed: "+sql);


                while(rs.next()){
                    notFound=false;
                    String EventID =  rs.getString("Event ID");
                    //System.out.println(perID);
                    String decendant = rs.getString("Decendant(Username)");
                    String person = rs.getString("Person");
                    String Lattitude = rs.getString("Lattitude");
                    String Longitude = rs.getString("Longitude");
                    //coun cit ty yr
                    String country = rs.getString("Country");
                    String city = rs.getString("City");
                    String type = rs.getString("Event Type");
                    String year = rs.getString("Year");

                    if(EventID.equals(eventID)) {
                        System.out.println("creating Event");
                        myEvent = new Event(EventID,decendant,person,Lattitude,Longitude,country,city,type,year);
                    }

                }


            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return myEvent;
    }


    public String retrieveBirth(String myPerson){
        Event myBirth = new Event();
        String birthYear="";

        try {
            Statement stmt = null;
            ResultSet rs = null;
            boolean notFound = false;
            try {
                //System.out.println("preparing to execute sql");
                String sql ="select* from events where `Person`= '"+myPerson+"' and `Event Type`= 'birth' ";


                stmt = connection.createStatement();
                rs = stmt.executeQuery(sql);

                //System.out.println(rs.next());
                //returns true if found, false if  not



                //System.out.println("query executed: "+sql);


                while(rs.next()){
                    //System.out.println(perID);
                     birthYear = rs.getString("Year");




                }


            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return birthYear;
    }

    public void insertEvent(Event myEvent){
        String SQL="";

        try {
            Statement stmt = null;
            try {
                stmt = connection.createStatement();

                //                stmt.executeUpdate("drop table if exists users");
                //System.out.println(person.getPersonID());


//insert into member (name, email_address) values ('Ann', 'ann@cs.byu.edu');
                 SQL = "insert into events ('Event ID', 'Decendant(Username)', 'Person', 'Lattitude' , Longitude, 'Country', 'City', 'Event Type', 'Year') values (\'"+myEvent.getEventID()+ "\', \'" + myEvent.getDecendant()+"\', \'"+myEvent.getPersonID()+"\', \'"+ myEvent.getLattitude()+"\', \'"+myEvent.getLongitude()+ "\', \'"+myEvent.getCountry()+"\', \'"+myEvent.getCity()+"\', \'"+myEvent.getType()+"\', \'"+myEvent.getYear()+"\')";

                stmt.executeUpdate(SQL);

            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println( SQL);

        }
    }

    //birth, baptism, marriage, and death
    public void generateEvents( Person myPerson,boolean isRoot,String relevantYear){
        //System.out.println("creating events for: "+isRoot);
        createEvent(myPerson,"birth",relevantYear,isRoot);
        createEvent(myPerson,"baptism",relevantYear,isRoot);
       // createEvent(myPerson,"marriage",relevantYear,isRoot);
        createEvent(myPerson,"death",relevantYear,isRoot);

    }


    public void setConnection(Connection newConnection){ connection = newConnection;}

    public void setLocationFile(locations myLoca){
        myLocations = myLoca;
    }

    public  void setCurrEvent(Event event){ currEvent = event;}

}