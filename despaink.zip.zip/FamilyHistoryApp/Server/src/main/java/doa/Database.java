package doa;

import com.google.gson.*;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.lang.*;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import org.sqlite.*;

import doa.AuthorizationTokenDAO;
import doa.EventDAO;
import doa.PersonDAO;
import doa.UserDAO;
import doa.databaseFile.EventFile;
import doa.databaseFile.PersonFile;
import model.AuthorizationToken;
import model.Event;
import model.Person;
import model.User;
import doa.names.*;


public class Database {
    static {
        try {
            final String driver = "org.sqlite.JDBC";
            Class.forName(driver);
        }
        catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    public Database(){

        myUser = new UserDAO();
        myPerson= new PersonDAO();
        myEvent = new EventDAO();
        myAuthorizationToken = new AuthorizationTokenDAO();
        loadGenerationFiles();
        myEvent.setLocationFile(myLocations);
        myPerson.setFiles(myMaleNames,myFemaleNames,myFamilyNames, myEvent);
        persons= new PersonFile();
        events = new EventFile();

        System.out.println("database constructed");



    }

    private Connection connection;

    protected UserDAO myUser;
    protected PersonDAO myPerson;
    protected AuthorizationTokenDAO myAuthorizationToken;
    protected EventDAO myEvent;

    private male myMaleNames;
    private female myFemaleNames;
    private family myFamilyNames;
    private locations myLocations;

    private PersonFile persons;
    private EventFile events;


    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public void loadGenerationFiles(){
        Gson myGson= new Gson();
        System.out.println(" loading files for names and places");
        try{
            Reader reader = new FileReader("json/locations.json");
            myLocations = myGson.fromJson(reader, locations.class);

            reader = new FileReader("json/fnames.json");
            myFemaleNames = myGson.fromJson(reader,female.class);

            reader = new FileReader("json/mnames.json");
            myMaleNames = myGson.fromJson(reader,male.class);

            reader = new FileReader("json/snames.json");
            myFamilyNames = myGson.fromJson(reader,family.class);


        }catch (FileNotFoundException e){ e.printStackTrace(); System.out.println("failed to load files");}

    }

    public void loadUsers( User[] users){
        for(int i =0; i<users.length; i++){
            myUser.insertUser(users[i]);
        }
    }

    public void loadPersons(Person[]persons){
        for(int i=0;i<persons.length;i++){
            myPerson.insertPerson(persons[i]);
            //System.out.println(persons[i].getFather());
        }
    }

    public void loadEvents(Event[]events){
        for(int i = 0;i<events.length;i++){
            myEvent.insertEvent(events[i]);
            //System.out.println(events[i].getDecendant());
        }
    }

    public UserDAO getMyUser() {
        return myUser;
    }

    public void setMyUser(UserDAO myUser) {
        this.myUser = myUser;
    }

    public String getMyUserName(){ return myUser.getUsername(); }

    public String getMyUserID(){ return myUser.getPersonID();}

    public PersonDAO getMyPerson() {
        return myPerson;
    }

    public void setMyPerson(PersonDAO myPerson) {
        this.myPerson = myPerson;
    }

    public AuthorizationTokenDAO getMyAuthorizationToken() {
        return myAuthorizationToken;
    }

    public void setMyAuthorizationToken(AuthorizationTokenDAO myAuthorizationToken) {
        this.myAuthorizationToken = myAuthorizationToken;
    }

    public String getMyToken(){return myAuthorizationToken.getMyToken();}

    public EventDAO getMyEvent() {
        return myEvent;
    }

    public void setMyEvent(EventDAO myEvent) {
        this.myEvent = myEvent;
    }

    public void openConnection() throws SQLException {
        try {
            //System.out.println("openning connection for database");
            final String CONNECTION_URL = "jdbc:sqlite:database.sqlite";

            // Open a database connection
            connection = DriverManager.getConnection(CONNECTION_URL);

            // Start a transaction
            connection.setAutoCommit(false);
            //System.out.println("connection established, autocommit is false");

            myUser.setConnection(getConnection());
            myPerson.setConnection(getConnection());
            myEvent.setConnection(getConnection());
            myAuthorizationToken.setConnection(getConnection());
            myAuthorizationToken.setMyUserDAO(myUser);
            //System.out.println("Connections are set");
        }
        catch (SQLException e) {
            throw new SQLException("openConnection failed", e);
        }
    }

    public void closeConnection(boolean commit) throws SQLException {
        try {
            if (commit) {
                connection.commit();
            }
            else {
                connection.rollback();
            }

            connection.close();
            connection = null;
        }
        catch (SQLException e) {
            throw new SQLException("closeConnection failed", e);
        }
    }

    public void createTables() throws SQLException {
        System.out.println("beginning create Tables");
        try {
            Statement stmt = null;
            try {
                stmt = connection.createStatement();

                stmt.executeUpdate("drop table if exists users");
                stmt.executeUpdate("drop table if exists authorizationTokens");
                stmt.executeUpdate("drop table if exists persons");
                stmt.executeUpdate("drop table if exists events");

                 System.out.println("dropped tables");

                stmt.executeUpdate("create table users (Username TEXT not NULL UNIQUE," +
                        "Password TEXT NOT NULL," +
                        "Email TEXT NOT NULL," +
                        "'First Name' TEXT NOT NULL," +
                        "'Last Name' TEXT NOT NULL, " +
                        "Gender TEXT NOT NULL, " +
                        "'Person ID' TEXT NOT NULL UNIQUE," +
                        "PRIMARY KEY(Username) )");
                 System.out.println("finished first table");

                stmt.executeUpdate("create table authorizationTokens ( " +
                        "Token TEXT NOT NULL UNIQUE," +
                        "Username TEXT NOT NULL," +
                        "PRIMARY KEY(Token))");

                // System.out.println("finished second table");

                stmt.executeUpdate("create table persons ( " +
                        "`Person ID`TEXT NOT NULL UNIQUE," +
                        "`Decendant(Username)`TEXT NOT NULL," +
                        "`First Name`TEXT NOT NULL," +
                        "`Last Name`TEXT NOT NULL," +
                        "`Gender`TEXT NOT NULL," +
                        "`Father(ID)`TEXT," +
                        "`Mother(ID)`TEXT," +
                        "`Spouse(ID)`TEXT," +
                        "PRIMARY KEY(`Person ID`) )");

                stmt.executeUpdate("create table events ( \n" +
                        "\t`Event ID`\tTEXT NOT NULL UNIQUE,\n" +
                        "\t`Decendant(Username)`\tTEXT NOT NULL,\n" +
                        "\t`Person`\tTEXT NOT NULL,\n" +
                        "\t`Lattitude`\tNUMERIC NOT NULL,\n" +
                        "\t`Longitude`\tNUMERIC NOT NULL,\n" +
                        "\t`Country`\tTEXT NOT NULL,\n" +
                        "\t`City`\tTEXT NOT NULL,\n" +
                        "\t`Event Type`\tTEXT NOT NULL,\n" +
                        "\t`Year`\tTEXT NOT NULL,\n" +
                        "\tPRIMARY KEY(`Event ID`) )");


                //TODO: create the Tables
            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
            throw new SQLException("createTables failed", e);
        }
    }

    //returns true if found
    public boolean findUser(String userName) throws SQLException{


        try {
            Statement stmt = null;
            ResultSet rs = null;
            boolean notFound = false;
            try {
                //System.out.println("preparing to execute sql");
                String sql ="select userName from users where userName = \'"+userName+"\' ";


                stmt = connection.createStatement();
                  rs = stmt.executeQuery(sql);
                System.out.println("query executed: "+"select userName from users where userName = \'"+userName+"\' ");

                  //System.out.println(rs.next());
                //returns true if found, false if  not

                while(rs.next()){
                    return true;
                }



                return false;


            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
            throw new SQLException("findUser failed", e);
        }



    }

    public void loginUser(String name, String password){
        // already confirmed user was in the data base... now set currUser, make an authToken and return what they want
        User temp = new User();
        temp = myUser.retrieveUser(name, password);
        myUser.setCurrUser(temp);
        createAuthToken(myUser.currUser);
    }

    public void createUser(String name, String pass, String email, String first, String last, String gender, int generations) throws SQLException{
        System.out.println("preparing to createUser");
        myUser.createUser(name,pass,email,first,last,gender);
        System.out.println("created user in database");
        createPerson(myUser.currUser, myUser.currUser.getId(),generations);
        System.out.println("created the person for root user");
        //createPersons(4);
        //System.out.println("created "+4+" generations for the root user");
        createAuthToken(myUser.currUser);

    }

    public void createUser(String name, String pass, String email, String first, String last, String gender, int generations,String personID) throws SQLException{
        System.out.println("preparing to createUser");
        myUser.createUser(name,pass,email,first,last,gender,personID);
        System.out.println("created user in database");
        createPerson(myUser.currUser, myUser.currUser.getId(),generations);
        System.out.println("created the person for root user");
        //createPersons(4);
        //System.out.println("created "+4+" generations for the root user");
        createAuthToken(myUser.currUser);

    }


    public void createPerson(User user, String myID, int generations) {
        System.out.println("entered create person for root user");
        try {
            myUser.currUser.setId(myID);
            myPerson.createPerson(myUser.currUser,generations);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public String fill(String Username) throws SQLException {
        String message="";
        int generations = 4;

         boolean isFound = findUser(Username); // throws exception if not found

        if(isFound) {
            User temp = myUser.retrieveUser(Username);

            //clear all data associated with this user
            //deleteUser(Username);
            clear(Username);

            Person tempPerson=new Person();

            myUser.setCurrUser(temp);
            //removed in preference of create person
            //createUser(temp.getUserName(),temp.getPassword(),temp.getEmail(),temp.getFirstName(),temp.getLastName(),temp.getGender(),generations,temp.getId());
            createPerson(temp,temp.getId(),4);
            message ="{\"message\": \"Successfully added 31 persons and 93 events to the database.\"}";

        }
        else{
            message ="{\"message\": \"Username not found.\"}";

        }

        return message;
    }

    public String fill(String Username, int generations) throws SQLException {
        System.out.println("entered fill w/ generations");
        int personNum=0;
        int eventNum=0;

        /*
        double tempgen;
        String genStr = Integer.toString(generations);
        tempgen = Math.pow(2,generations+1);
        personNum = Integer.parseInt(Double.toString(tempgen)) -1;

*/
        personNum = (int)Math.pow(2,generations+1) -1;
        eventNum = personNum *3;

        String message="";

        boolean isFound = findUser(Username); // throws exception if not found
        System.out.println(isFound);


        if(isFound) {
            System.out.println(" username isfound");
            User temp = myUser.retrieveUser(Username);

            //clear all data associated with this user
            //deleteUser(Username);
            clear(Username);
            System.out.println(" data is deleted");

            Person tempPerson=new Person();

            myUser.setCurrUser(temp);
            //createUser(temp.getUserName(),temp.getPassword(),temp.getEmail(),temp.getFirstName(),temp.getLastName(),temp.getGender(),generations,temp.getId());
            createPerson(temp,temp.getId(),generations);
            message ="{\"message\": \"Successfully added "+personNum+" persons and "+eventNum+" events to the database.\"}";
            System.out.println(message);

        }
        else{
            message ="{\"message\": \"Username not found.\"}";

        }

        return message;
    }

    public String clear(String Username) throws SQLException {
        String message="";

//DELETE FROM table_name WHERE condition;

        try {
            Statement stmt = null;
            boolean notFound = false;
            try {
                //System.out.println("preparing to execute sql");
                String sql ="delete from persons where `Decendant(Username)` = '"+Username+"' ";

                //String SQL = "insert into users (Username, Password, Email, 'First Name', 'Last Name', Gender, 'Person ID') values (\'"+



                  stmt = connection.createStatement();
                  stmt.executeUpdate(sql);

                sql ="delete from persons where `Decendant(Username)` = '"+Username+"' ";

                stmt = connection.createStatement();
                stmt.executeUpdate(sql);

                sql ="delete from events where `Decendant(Username)` = '"+Username+"' ";

                stmt = connection.createStatement();
                stmt.executeUpdate(sql);





                //System.out.println(rs.next());
                //returns true if found, false if  not



                //System.out.println("query executed");




            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
            throw new SQLException("clear failed", e);
        }

        return message;
    }

    public void deleteUser(String Username)throws SQLException{
        try {
            Statement stmt = null;
            boolean notFound = false;
            try {

                String sql ="delete from users where `Username` = '"+Username+"' ";

                stmt = connection.createStatement();
                stmt.executeUpdate(sql);

            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
            throw new SQLException("delete user failed", e);
        }
    }

    public String getPerson(String PersonID,String authToken){
        System.out.println("entered get person in databaseDAO");
        String message="";
        Person temp = new Person();
        try {

            temp = myPerson.retrievePerson(PersonID);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if(temp.getFirstName()==null){
            message ="{\"message\": \"Person not found.\"}";
            return message;
        }

        if(!validateAuthToken(authToken)){
            message ="{\"message\": \"The given authToken if not found in our system.\"}";
            return message;

        }
        System.out.println(myUser.currUser.getUserName());
        System.out.println(temp.getDescendant());
        if( !((temp.getDescendant()).equals(myUser.currUser.getUserName())) ){
            message ="{\"message\": \"The given authToken does not allow access to this person.\"}";
            return message;
        }



        Gson gson =new Gson();

        message= gson.toJson(temp);

        return message;
    }

    public String getPersons(String authToken){
        String message="";
        Person temp = new Person();
        //sets currUser to the one I want
        if(myAuthorizationToken.validateToken(authToken)){
            //use user to get all the persons
            setMyUser(myAuthorizationToken.getMyUserDAO());
            System.out.println("Dao is set");

            String userName = myUser.currUser.getUserName();
            System.out.println("userName is:"+userName);

            //sql for all persons with this decendant
            try {
                Statement stmt = null;
                ResultSet rs = null;
                //boolean notFound = false;
                try {
                    //System.out.println("preparing to execute sql");
                    String sql ="select* from persons where `Decendant(Username)`= '"+userName+"' ";


                    stmt = connection.createStatement();
                    rs = stmt.executeQuery(sql);

                    //System.out.println(rs.next());
                    //returns true if found, false if  not



                    System.out.println("query executed: "+sql);

                    while(rs.next()){
                        //System.out.println(perID);
                        //System.out.println("getting person");

                        String personID = rs.getString("Person ID");
                        String first = rs.getString("First Name");
                        String last = rs.getString("Last Name");
                        String gender = rs.getString("Gender");
                        String father = rs.getString("Father(ID)");
                        if(rs.getString("Father(ID)").equals("SQL NULL")){
                            System.out.println("Father is null");
                        }
                        String mother = rs.getString("Mother(ID)");
                        String spouse = rs.getString("Spouse(ID)");

                        //System.out.println("creating new person: "+ first);



                        temp = new Person(first,last,gender,personID,userName,mother,father,spouse);
                        //System.out.println("person created");
                        //System.out.println("first name is: "+temp.getFirstName());

                        persons.addPerson(temp);

                    }


                }
                finally {
                    if (stmt != null) {
                        stmt.close();
                        stmt = null;
                    }
                }
            }
            catch (SQLException e) {
                System.err.println(e.getMessage());
            }

        }
        else{
            message ="{\"message\": \"The given authToken if not found in our system.\"}";
            return message;
        }

        Gson gson =new Gson();

        message= gson.toJson(persons);

        return message;
    }

    public String getEvent(String EventID, String authToken){
        System.out.println(EventID);
        String message="";
        Event temp = new Event();

            temp = myEvent.retrieveEvent(EventID);



        if(temp.getPersonID()==null){
            //System.out.println("person for event is null");
            message ="{\"message\": \"Event not found.\"}";
            return message;
        }

        if(!validateAuthToken(authToken)){
            message ="{\"message\": \"The given authToken if not found in our system.\"}";
            return message;

        }
        //System.out.println(myUser.currUser.getUserName());
        //System.out.println(temp.getDecendant());
        if( !((temp.getDecendant()).equals(myUser.currUser.getUserName())) ){
            message ="{\"message\": \"The given authToken does not allow access to this event.\"}";
            return message;
        }



        Gson gson =new Gson();

        message= gson.toJson(temp);

        return message;
    }

    public String getEvents(String authToken){
        String message="";
        Event temp = new Event();
        //sets currUser to the one I want
        if(myAuthorizationToken.validateToken(authToken)){
            //use user to get all the persons
            setMyUser(myAuthorizationToken.getMyUserDAO());
            //System.out.println("Dao is set");

            String userName = myUser.currUser.getUserName();
            //System.out.println("userName is:"+userName);

            //sql for all persons with this decendant
            try {
                Statement stmt = null;
                ResultSet rs = null;
                //boolean notFound = false;
                try {
                    //System.out.println("preparing to execute sql");
                    String sql ="select* from events where `Decendant(Username)`= '"+userName+"' ";


                    stmt = connection.createStatement();
                    rs = stmt.executeQuery(sql);





                    System.out.println("query executed: "+sql);

                    while(rs.next()){
                        System.out.println("getting next");
                        String EventID =  rs.getString("Event ID");

                        String decendant = rs.getString("Decendant(Username)");

                        String person = rs.getString("Person");

                        String Lattitude = rs.getString("Lattitude");

                        String Longitude = rs.getString("Longitude");

                        //coun cit ty yr
                        String country = rs.getString("Country");
                        String city = rs.getString("City");
                        String type = rs.getString("Event Type");
                        String year = rs.getString("Year");

                        //System.out.println("creating new person: "+ first);


                        System.out.println("preparing to create event");
                        temp = new Event(EventID,decendant,person,Lattitude,Longitude,country,city,type,year);
                        //System.out.println("person created");
                        //System.out.println("first name is: "+temp.getFirstName());

                        events.addEvent(temp);

                    }


                }
                finally {
                    if (stmt != null) {
                        stmt.close();
                        stmt = null;
                    }
                }
            }
            catch (SQLException e) {
                System.err.println(e.getMessage());
            }

        }
        else{
            message ="{\"message\": \"The given authToken if not found in our system.\"}";
            return message;
        }

        Gson gson =new Gson();

        message= gson.toJson(events);

        return message;
    }


    public void createAuthToken(User user){
        System.out.println("Entered create AuthToken for user");
        myAuthorizationToken.createToken(user);



    }

    public boolean validateAuthToken(String authToken){
        //System.out.println("preparing to validate AuthToken");

        return myAuthorizationToken.validateToken(authToken);
    }

    public static void main(String [] args) throws SQLException{

        Database myDatabase = new Database();
        myDatabase.openConnection();
        myDatabase.createTables();
        myDatabase.createUser("me","despk","kdwspain","kendall","despain", "m",4);
        Person temp = new Person();
        Person temp2 = new Person();
        //temp = myDatabase.myPerson.currPerson;
       // temp2 = myDatabase.myPerson.retrievePerson(temp.getPersonID());

        //System.out.println( temp.getPersonID());

        //System.out.println( temp2.getFirstName());

        myDatabase.closeConnection(true);

    }
}
