package doa.names;

public class cities {
    String country;
    String city;
    String latitude;
    String longitude;

    public String getCountry() {
        return country;
    }

    public String getCity() {
        return city;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getLongitude() {
        return longitude;
    }


}
