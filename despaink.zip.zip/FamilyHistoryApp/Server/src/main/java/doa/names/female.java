package doa.names;

import java.util.concurrent.ThreadLocalRandom;

public class female {
    public String[] data;

    public int getSize(){return data.length;}

    public String randomName(){

        int randomNum = ThreadLocalRandom.current().nextInt(0, getSize());

        return data[randomNum];
    }

}
