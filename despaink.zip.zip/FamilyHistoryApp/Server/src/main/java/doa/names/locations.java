package doa.names;

import java.util.concurrent.ThreadLocalRandom;

public class locations {

    public cities[] data;

    public int getSize(){return data.length;}

    public  cities randomCity(){

        int randomNum = ThreadLocalRandom.current().nextInt(0, getSize());


        return data[randomNum];
    }
}
