package doa;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;

import model.Person;
import model.User;

public class UserDAO {
    public UserDAO() {    }

    private Connection connection;
    protected User currUser;


    /**
     * creates a user
     * generates a tuple in the  user table using the user object
     **/
    public void createUser( String userName, String password, String email, String firstName, String lastName, String gender) throws SQLException{
        try {
            Statement stmt = null;
            try {
                stmt = connection.createStatement();

                //                stmt.executeUpdate("drop table if exists users");


//insert into member (name, email_address) values ('Ann', 'ann@cs.byu.edu');
                UUID personID = UUID.randomUUID();
                String SQL = "insert into users (Username, Password, Email, 'First Name', 'Last Name', Gender, 'Person ID') values (\'"+
                        userName+ "\', \'" + password+"\', \'"+email+"\', \'"+ firstName+"\', \'"+lastName+ "\', \'"+gender+"\', \'"+personID+"\')";

                stmt.executeUpdate(SQL);
                setCurrUser(userName,password,email,firstName,lastName,gender,personID.toString());

            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            throw new SQLException("createUser in DAO failed", e);
        }
    }

    public void createUser( String userName, String password, String email, String firstName, String lastName, String gender,String ID) throws SQLException{
        try {
            Statement stmt = null;
            try {
                stmt = connection.createStatement();

                //                stmt.executeUpdate("drop table if exists users");


//insert into member (name, email_address) values ('Ann', 'ann@cs.byu.edu');
                UUID personID = UUID.fromString(ID);
                String SQL = "insert into users (Username, Password, Email, 'First Name', 'Last Name', Gender, 'Person ID') values (\'"+
                        userName+ "\', \'" + password+"\', \'"+email+"\', \'"+ firstName+"\', \'"+lastName+ "\', \'"+gender+"\', \'"+personID+"\')";

                stmt.executeUpdate(SQL);
                setCurrUser(userName,password,email,firstName,lastName,gender,personID.toString());

            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            throw new SQLException("createUser in DAO failed", e);
        }
    }


    /**
     *uses ID to find the user in the user table
     * uses the password to validate the user
     * builds a user object using the values found in the user table
     **/
    public User retrieveUser(String name, String password){
        User temp = new User();
        try {
            Statement stmt = null;
            ResultSet rs = null;
            boolean notFound = false;
            try {
                //System.out.println("preparing to execute sql");
                String sql ="select* from users where `Username` = '"+name+"' and `Password` ='"+password+"' ";


                stmt = connection.createStatement();
                rs = stmt.executeQuery(sql);

                //System.out.println(rs.next());
                //returns true if found, false if  not



                System.out.println("query executed: "+sql);


                while(rs.next()){
                    //System.out.println(perID);
                    String userName = rs.getString("Username");
                    String pass = rs.getString("Password");
                    String email = rs.getString("Email");
                    String first = rs.getString("First Name");
                    String last = rs.getString("Last Name");
                    String gender = rs.getString("Gender");
                    String personID = rs.getString("Person ID");


                        System.out.println("creating user");
                        temp = new User( userName,pass,email,first,last,gender,personID);


                }


            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        System.out.println("returing user");

        return temp;
    }

    public User retrieveUser(String name){
        User temp = new User();
        try {
            Statement stmt = null;
            ResultSet rs = null;
            boolean notFound = false;
            try {
                //System.out.println("preparing to execute sql");
                String sql ="select* from users where `Username`= '"+name+"' ";


                stmt = connection.createStatement();
                rs = stmt.executeQuery(sql);

                //System.out.println(rs.next());
                //returns true if found, false if  not



                System.out.println("query executed: "+sql);


                while(rs.next()){
                    //System.out.println(perID);
                    String userName = rs.getString("Username");
                    String pass = rs.getString("Password");
                    String email = rs.getString("Email");
                    String first = rs.getString("First Name");
                    String last = rs.getString("Last Name");
                    String gender = rs.getString("Gender");
                    String personID = rs.getString("Person ID");

                        System.out.println("creating user");
                        temp = new User( userName,pass,email,first,last,gender,personID);


                }


            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return temp;
    }

    public void insertUser(User user){
        try {
            Statement stmt = null;
            try {
                stmt = connection.createStatement();

                //                stmt.executeUpdate("drop table if exists users");
                //System.out.println(person.getPersonID());


//insert into member (name, email_address) values ('Ann', 'ann@cs.byu.edu');
                String SQL = "insert into users ('Username', 'Password', 'Email', 'First Name', 'Last Name' , Gender, 'Person ID') values (\'"+user.getUserName()+ "\', \'" + user.getPassword()+"\',\'"+user.getEmail()+"\', \'"+user.getFirstName()+"\', \'"+ user.getLastName()+"\', \'"+user.getGender()+ "\', \'"+user.getId()+"\')";

                stmt.executeUpdate(SQL);

            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void setConnection(Connection newConnection){ connection = newConnection;}

    public void setCurrUser(String name, String pass, String email, String first, String last, String gender,String personID){
        currUser = new User(name,pass,email,first,last,gender,personID);
    }

    public void setCurrUser(User temp){
        currUser = temp;
    }

    public String getUsername(){return currUser.getUserName();}

    public String getPersonID(){return currUser.getId();}

}
