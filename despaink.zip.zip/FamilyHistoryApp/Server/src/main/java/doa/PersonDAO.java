package doa;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.TreeSet;
import java.util.UUID;

import doa.names.family;
import doa.names.female;
import doa.names.male;
import model.AuthorizationToken;
import model.Person;
import model.User;

public class PersonDAO {
    public PersonDAO() {
    }


    private Connection connection;
    protected Person currPerson;
    protected Person tempPerson;

    protected  EventDAO myEventDOA;

    private male myMaleNames;
    private female myFemaleNames;
    private family myFamilyNames;


    /**
     * @param user
     * generates a person who is the given user and their family tree
     **/
    public void createPerson(User user,int generations) throws SQLException {
        System.out.println("in personDAO in createPerson(user)");

        currPerson = new Person(user);

        tempPerson = currPerson;
        System.out.println("person(user) set to currPerson");

            insertPerson(currPerson);
            myEventDOA.generateEvents(currPerson,true,"2018");


        createPersons(generations,user);
    }

    public void createPersons(int generations, User user){
        //System.out.println("create persons stub");
        createPersonsHelper(generations,user.getUserName(),currPerson,false);
    }

    public void createPersonsHelper(int generations, String decendant, Person ourkid, boolean isLast){
        Person husband= new Person();
        Person wife= new Person();
        if(generations>0) {
            if(generations==1){ isLast=true;}
            tempPerson= ourkid;
//   String firstName, String lastName, String gender, UUID myID, String userName, boolean isLast
            husband= new Person( myMaleNames.randomName(),ourkid.getLastName(),"m",ourkid.getFather(),decendant,isLast);

            wife = new Person( myFemaleNames.randomName(),myFamilyNames.randomName(),"f",ourkid.getMother(),decendant,isLast);
            husband.setSpouse(wife.getPersonID());
            wife.setSpouse(husband.getPersonID());


                insertPerson(husband);
                myEventDOA.generateEvents(husband,false,myEventDOA.retrieveBirth(ourkid.getPersonID()));
                insertPerson(wife);
                myEventDOA.generateEvents(wife,false,myEventDOA.retrieveBirth(ourkid.getPersonID()));

            generations--;

            createPersonsHelper(generations, decendant, husband,isLast);
            createPersonsHelper(generations, decendant, wife,isLast);
        }


    }
    /**
     * creates a person object using the values found in the person table
     **/
    public void insertPerson(Person person)  {
        try {
            Statement stmt = null;
            try {
                stmt = connection.createStatement();

                //                stmt.executeUpdate("drop table if exists users");
                //System.out.println(person.getPersonID());


//insert into member (name, email_address) values ('Ann', 'ann@cs.byu.edu');
                String SQL = "insert into persons ('Person ID', 'Decendant(Username)', 'First Name', 'Last Name' , Gender, 'Father(ID)', 'Mother(ID)', 'Spouse(ID)') values (\'"+person.getPersonID()+ "\', \'" + person.getDescendant()+"\', \'"+person.getFirstName()+"\', \'"+ person.getLastName()+"\', \'"+person.getGender()+ "\', \'"+person.getFather()+"\', \'"+person.getMother()+"\', \'"+person.getSpouse()+"\')";

                stmt.executeUpdate(SQL);

            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Person retrievePerson( String personID) throws SQLException {
        System.out.println("entered retrieve person id: "+personID);
        Person myPerson = new Person();
        try {
            Statement stmt = null;
            ResultSet rs = null;
            boolean notFound = true;
            try {
                //System.out.println("preparing to execute sql");
                String sql ="select* from persons where `Person ID`= '"+personID+"' ";


                stmt = connection.createStatement();
                rs = stmt.executeQuery(sql);

                //System.out.println(rs.next());
                //returns true if found, false if  not



                System.out.println("query executed: "+sql);


                while(rs.next()){
                    notFound=false;
                    String perID =  rs.getString("Person ID");
                    //System.out.println(perID);
                    String decendant = rs.getString("Decendant(Username)");
                    String first = rs.getString("First Name");
                    String last = rs.getString("Last Name");
                    String gender = rs.getString("Gender");
                    String father = rs.getString("Father(ID)");
                    String mother = rs.getString("Mother(ID)");
                    String spouse = rs.getString("Spouse(ID)");

                    if(perID.equals(personID)) {
                        System.out.println("creating person");
                        myPerson = new Person(first, last, gender, perID, decendant, mother, father, spouse);
                    }

                }


            }
            finally {
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
            }
        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return myPerson;
    }
    /**
     * retrieves all people associated with the user found in the person table
     **/
    public TreeSet<Person> retrievePersons(User user){ TreeSet<Person> myFamily = new TreeSet<Person>(); return myFamily;}

    public void setConnection(Connection newConnection){ connection = newConnection; }

    public void setFiles(male myMales, female myFemales, family myFamilies, EventDAO myEvent){
        myMaleNames = myMales;
        myFemaleNames = myFemales;
        myFamilyNames = myFamilies;
        myEventDOA =myEvent;

    }


}
