package model;

import java.sql.Connection;
import java.util.UUID;

import doa.UserDAO;

public class AuthorizationToken {
    /**
     * given a user generates a new UUID AuthToken
     **/
    public AuthorizationToken( User u) {
        token = UUID.randomUUID().toString();
        user = u;
    }
    /**
     * constructs an AuthToken
     **/
    public AuthorizationToken(String myToken, User myUser){
        token=myToken.toString();
        user=myUser;
    }

    public AuthorizationToken(){}





    private String token;
    private User user;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }


}