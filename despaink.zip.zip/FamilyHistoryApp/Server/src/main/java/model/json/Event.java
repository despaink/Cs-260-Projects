package model.json;

public class Event {
}
