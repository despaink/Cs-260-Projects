package model.json;

import java.util.UUID;

public class User {

    private String userName;
    private String password;
    private String PersonID;
    private String email;
    private String firstName;
    private String lastName;
    private String gender;
}
