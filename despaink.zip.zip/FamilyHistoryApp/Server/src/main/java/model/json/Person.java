package model.json;

public class Person {
}
