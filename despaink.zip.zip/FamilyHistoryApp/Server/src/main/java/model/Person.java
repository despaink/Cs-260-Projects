package model;

import java.sql.Connection;
import java.util.UUID;

public class Person {
    public Person() {
    }
    public Person(User user){
        System.out.println("building person from user");

        setFirstName(user.getFirstName());
        setLastName(user.getLastName());
        setDescendant(user.getUserName());
        setGender(user.getGender());
        setPersonID(user.getId());
        setFather(UUID.randomUUID().toString());
        setMother(UUID.randomUUID().toString());
        setSpouse(null);
    }

    public Person(String firstName, String lastName, String gender, String myID, String userName, String mother, String father, String spouse ){
        System.out.println("building total person");

        setFirstName(firstName);
        setLastName(lastName);
        setGender(gender);
        setPersonID(myID.toString());
        setDescendant(userName);

        //System.out.println("mother is: "+ mother);

            setMother(mother);




            setFather(father);


            setSpouse(spouse);


    }


    public Person( String firstName, String lastName, String gender, String myID, String userName,  boolean isLast){
        //System.out.println("building leaf(last) person");

        setFirstName(firstName);
        setLastName(lastName);
        setGender(gender);
        setPersonID(myID);
        setDescendant(userName);
        setSpouse(null);

        if(isLast){
            setFather(null);
            setMother(null);
        }
        else{
            setFather(UUID.randomUUID().toString());
            setMother(UUID.randomUUID().toString());
        }

    }




    private String firstName;
    private String lastName;
    private String gender;
    private String personID;
    private String descendant;
    private String mother;
    private String father;
    private String spouse;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getDescendant() {
        return descendant;
    }

    public void setDescendant(String descendant) {
        this.descendant = descendant;
    }

    public String getMother() {
        return mother;
    }

    public void setMother(String mymother) {
        mother = mymother;
    }

    public String getFather() {
        return father;
    }

    public void setFather(String myfather) {
        father = myfather;
    }

    public String getSpouse() {
        return spouse;
    }

    public void setSpouse(String spouse) {
        this.spouse = spouse;
    }
}
