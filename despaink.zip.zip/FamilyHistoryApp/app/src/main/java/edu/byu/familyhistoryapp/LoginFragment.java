package edu.byu.familyhistoryapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.appcompat.*;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import model.DataFile;
import model.LoginRequest;
import model.LoginResponse;
import model.Person;
import model.PersonFile;
import model.RegisterRequest;
import serverProxy.Proxy;

public class LoginFragment extends Fragment implements LoginTask.ContextLogin , GetDataTask.ContextGetData, RegisterTask.ContextRegister  {

    public interface ContextOnGetData {
        //void onProgressUpdate(int percent);
        //void onDownloadComplete(long totalBytes);
        void onGetData(DataFile myData);
        void replaceFragments();
    }

    private ContextOnGetData context;

    private EditText serverPort_ET;
    private EditText serverHost_ET;
    private EditText userName_ET;
    private EditText password_ET;
    private EditText firstName_ET;
    private EditText lastName_ET;
    private EditText email_ET;
    private Button login_BTN;
    private Button register_BTN;
    private RadioGroup radioGroup;
    private RadioButton male_BTN;
    private RadioButton female_BTN;
    private Proxy  myProxy;

    private Activity activity = getActivity();

    public LoginFragment(ContextOnGetData c){
        context = c;
    }

    public LoginFragment(){}


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
         super.onCreateView(inflater, container, savedInstanceState);

        View v = inflater.inflate(R.layout.fragment_loginfragment, container, false);
        //wire up the widgets
        serverPort_ET = (EditText) v.findViewById(R.id.serverPort);
        serverHost_ET = (EditText) v.findViewById(R.id.serverHost);
        userName_ET = (EditText) v.findViewById(R.id.userName);
        password_ET = (EditText) v.findViewById(R.id.password);
        firstName_ET = (EditText) v.findViewById(R.id.firstName);
        lastName_ET = (EditText) v.findViewById(R.id.lastName);
        email_ET = (EditText) v.findViewById(R.id.email);
        radioGroup = v.findViewById(R.id.myRadioGroup);
        male_BTN = radioGroup.findViewById(R.id.maleButton);
        female_BTN = radioGroup.findViewById(R.id.femaleButton);

        login_BTN = v.findViewById(R.id.loginButton);
        register_BTN = v.findViewById(R.id.registerButton);


        login_BTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(hasNoEmptyFieldLogin()){
                    Toast.makeText(getActivity(),"Logging in",Toast.LENGTH_SHORT)
                            .show();

                    LoginRequest myRequest = new LoginRequest(userName_ET.getText().toString(),password_ET.getText().toString());

                    launchLoginTask(myRequest);

                }
                else {
                    Toast.makeText(getActivity(),"Not all of the required fields are given.",Toast.LENGTH_SHORT)
                            .show();
                }

            }
        });

        register_BTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(hasNoEmptyFieldRegister()){
                    Toast.makeText(getActivity(),"Registering",Toast.LENGTH_SHORT)
                            .show();
                    String gender = "";
                    if(male_BTN.isChecked()){
                        gender = "m";
                    }
                    else{
                        gender ="f";
                    }

                    RegisterRequest myRequest = new RegisterRequest(userName_ET.getText().toString(),
                            password_ET.getText().toString(),email_ET.getText().toString(),firstName_ET.getText().toString(),
                                lastName_ET.getText().toString(),gender);

                    launchRegisterTask(myRequest);
                }
                else {
                    Toast.makeText(getActivity(),"Not all of the required fields are filled.",Toast.LENGTH_SHORT)
                            .show();
                }

            }
        });

        return v;

    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }


    public boolean hasNoEmptyFieldRegister(){
        if(serverHost_ET.getText().toString().equals("")){
            return false;
        }
        if(serverPort_ET.getText().toString().equals("")){
            return false;
        }
        if(userName_ET.getText().toString().equals("")){
            return false;
        }
        if(password_ET.getText().toString().equals("")){
            return false;
        }
        if(firstName_ET.getText().toString().equals("")){
            return false;
        }
        if(lastName_ET.getText().toString().equals("")){
            return false;
        }
        if(email_ET.getText().toString().equals("")){
            return false;
        }

        return true;
    }

    public boolean hasNoEmptyFieldLogin(){
        if(serverHost_ET.getText().toString().equals("")){
            return false;
        }
        if(serverPort_ET.getText().toString().equals("")){
            return false;
        }
        if(userName_ET.getText().toString().equals("")){
            return false;
        }
        if(password_ET.getText().toString().equals("")){
            return false;
        }

        return true;
    }

    private void launchLoginTask( LoginRequest myRequest){
        LoginTask task = new LoginTask( this);

        task.execute(myRequest);
    }

    private void launchRegisterTask(RegisterRequest myRequest){
        RegisterTask task = new RegisterTask(this);
        task.execute(myRequest);
    }

    @Override
    public void onLoginComplete(LoginResponse myResponse) {
       // Toast.makeText(getActivity(),"_"+myResponse.getMessage()+"_",Toast.LENGTH_LONG).show();

        if(myResponse.getMessage()==null){
           //start a get data task
           // Toast.makeText(getActivity(),"Login Sucessful. Retriving user data.",Toast.LENGTH_SHORT).show();

            GetDataTask task = new GetDataTask(this);
            task.execute(myResponse);



        }
        else {
            Toast.makeText(getActivity(),myResponse.getMessage(),Toast.LENGTH_LONG)
                    .show();

        }


    }

    @Override
    public void onGetDataComplete(DataFile myData) {
        List<Person> data = myData.getMyPeople().getData();
        Toast.makeText(getActivity(),data.get(0).getFirstName()+" "+data.get(0).getLastName(),Toast.LENGTH_LONG).show();

        //TODO: insert info on how to store the family data here.
        context.onGetData(myData);

    }


}
