package edu.byu.familyhistoryapp;

import android.os.AsyncTask;

import model.LoginResponse;
import model.RegisterRequest;
import serverProxy.Proxy;

public class RegisterTask extends AsyncTask<RegisterRequest,String,LoginResponse> {

    public interface ContextRegister {
        //void onProgressUpdate(int percent);
        //void onDownloadComplete(long totalBytes);
        void onLoginComplete(LoginResponse myResponse);
    }
    ContextRegister context;

    public RegisterTask(ContextRegister c){
        context = c;
    }


    @Override
    protected LoginResponse doInBackground(RegisterRequest... requests) {
        Proxy proxy = new Proxy( "10.0.2.2","8080");

        return proxy.register(requests[0]);
    }

    @Override
    protected void onPostExecute(LoginResponse response) {
        context.onLoginComplete(response);
    }
}
