package edu.byu.familyhistoryapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import model.DataFile;
import model.HostAndAuth;
import model.Model;

public class SettingsActivity extends AppCompatActivity implements ResyncDataTask.ContextGetData {

    private LinearLayout logout_box_LL;
    private LinearLayout resync_box_LL;
    private LinearLayout map_type_box;
    private Spinner map_type_spinner;
    private Model myModel;
    private int caseResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);


        logout_box_LL = findViewById(R.id.logout_box);
        resync_box_LL =findViewById(R.id.resync_box);
        map_type_box = findViewById(R.id.map_type_box);
        map_type_spinner = findViewById(R.id.map_type_spinner);



        myModel = Model.getMyModel();

        logout_box_LL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myModel.setLoggedIn(false);

                Intent resultIntent = new Intent();
                resultIntent.putExtra("result_case", 1);
                setResult(Activity.RESULT_OK, resultIntent);
                finish();
            }



        });

        resync_box_LL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               launchResyncTask();

            }
        });

        //Normal (Default), Hybrid, Satellite, or Terrain
    List<String> mapTypeList = new ArrayList<String>();
    mapTypeList.add("normal");
    mapTypeList.add("hybrid");
    mapTypeList.add("satellite");
    mapTypeList.add("terrain");
    final List<String> finalMaptypeList = mapTypeList;


        map_type_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getBaseContext(), finalMaptypeList.get(position),Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



    }

    @Override
    public void onGetDataComplete(DataFile myData) {

        if(myData.message != null){
            Toast.makeText(this,myData.message,Toast.LENGTH_LONG).show();
            caseResult = 3;

            Intent resultIntent = new Intent();
            resultIntent.putExtra("result_case", caseResult);
            setResult(Activity.RESULT_OK, resultIntent);
            finish();

            }
        else{
            caseResult = 2;
            myModel = Model.makeMyModel(myData);

            Intent resultIntent = new Intent();
            resultIntent.putExtra("result_case", caseResult);
            setResult(Activity.RESULT_OK, resultIntent);
            finish();

        }
    }

    private void launchResyncTask(){
        ResyncDataTask resyncDataTask = new ResyncDataTask(this);

        resyncDataTask.execute( new HostAndAuth(myModel.getAuthToken(),myModel.getServerHost(),myModel.getServerPort()));
    }



}
