package edu.byu.familyhistoryapp;

import android.os.AsyncTask;

import model.LoginRequest;
import model.LoginResponse;
import serverProxy.Proxy;

public class LoginTask extends AsyncTask<LoginRequest,String, LoginResponse> {

    public interface ContextLogin {
        //void onProgressUpdate(int percent);
        //void onDownloadComplete(long totalBytes);
        void onLoginComplete(LoginResponse myResponse);
        //TODO: insert functions from LoginFragment that I want implemented use above format.
    }

    private ContextLogin context;

    public LoginTask(ContextLogin c){
        context = c;
    }

    @Override
    protected LoginResponse doInBackground(LoginRequest... myRequests) {
        Proxy proxy = new Proxy( "10.0.2.2","8080");

        return proxy.login(myRequests[0]);

    }

    @Override
    protected void onPostExecute(LoginResponse response) {
     context.onLoginComplete(response);
    }

}
