package edu.byu.familyhistoryapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;

import model.Model;

public class FilterActivity extends AppCompatActivity {

    Model myModel;
    ListView listView;
    //Switch fatherSide;
   // Switch motherSide;
   // Switch genderMale;
   // Switch genderFemale;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter);

        myModel =  Model.getMyModel();

        listView = findViewById(R.id.filter_list_view);
       // fatherSide = findViewById(R.id.father_side_switch);
       // motherSide = findViewById(R.id.mother_side_switch);
       // genderMale = findViewById(R.id.gender_male_switch);
       // genderFemale = findViewById(R.id.gender_female_switch);

        myModel.filterSetTypes.add("Father's Side");
        myModel.filterSetTypes.add("Mother's Side");
        myModel.filterSetTypes.add("Male Events");
        myModel.filterSetTypes.add("Female Events");


        String[] data;
        data = myModel.filterSetTypes.toArray(new String[myModel.filterSetTypes.size()]);

        listView.setAdapter(new myListAdapter(getBaseContext(),data));

        ActionBar ab = getSupportActionBar();

        ab.setDisplayHomeAsUpEnabled(true);

    }
@Override
    public boolean onOptionsItemSelected(MenuItem item){
    switch (item.getItemId()){

        case R.id.homeAsUp:

            Intent resultIntent = new Intent();
            resultIntent.putExtra("result_case", 2);
            setResult(Activity.RESULT_OK, resultIntent);
            finish();
            return true;

        default:
            return super.onOptionsItemSelected(item);
    }
}


}
