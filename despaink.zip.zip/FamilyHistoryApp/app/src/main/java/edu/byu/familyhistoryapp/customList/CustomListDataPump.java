package edu.byu.familyhistoryapp.customList;

import android.provider.CalendarContract;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import model.Event;
import model.Model;
import model.Person;

public class CustomListDataPump {

    static public HashMap<String, List<String>> getMyData (String personID){
        HashMap<String, List<String>> myData = new HashMap<>();

        Model myModel = Model.getMyModel();

        List<Event> myEvents = new ArrayList<Event>(myModel.MyEventMapByPerson.get(personID));
        List<String> myEventIDs = new ArrayList<>();

        for(int i = 0; i< myEvents.size(); i++){
            myEventIDs.add(myEvents.get(i).getEventID());

        }
        List<String> myPeople = new ArrayList<>();

        Person currPerson = myModel.allMyPeople.get(personID);

        if( !(currPerson.getFather().equals("null")) ){
            myPeople.add(currPerson.getFather());
        }
        if( !(currPerson.getMother().equals("null")) ){
            myPeople.add(currPerson.getMother());
        }
        if( !(currPerson.getSpouse().equals("null")) ){
            myPeople.add(currPerson.getSpouse());
        }

        myData.put("Events",myEventIDs);
        myData.put("People", myPeople);

        return  myData;
    }

    private ArrayList<Event> sortMyList(ArrayList<Event> myEventList){
        ArrayList<Event> mySortedList = new ArrayList<Event>(myEventList.size());
        int currentIndex = 0;
        int endingIndex = myEventList.size()-1;
        int yearToBeat =0;
        //look for birth and death
        for(int i = 0; i<myEventList.size(); i++){

            if(myEventList.get(i).getType().toLowerCase().equals("birth")){
                mySortedList.add(0,myEventList.get(i));
                currentIndex = 1;
                yearToBeat = Integer.parseInt( myEventList.get(i).getYear());
            }
            if(myEventList.get(i).getType().toLowerCase().equals("death")){
                mySortedList.add(myEventList.size()-1,myEventList.get(i));
                endingIndex= myEventList.size() - 2;
            }

        }

        //sort the rest of the events year then event type toLower
        while(currentIndex != endingIndex){
            Event possibleEvent = new Event();
            for(int i = 0; i< myEventList.size(); i++){
                if( myEventList.get(i).getType().toLowerCase().equals("birth") || myEventList.get(i).getType().toLowerCase().equals("death"))
                {}
                else{
                    possibleEvent = myEventList.get(i);
                    //has already been added
                    if(Integer.parseInt(possibleEvent.getYear()) <= yearToBeat){
                        //if it is the same year, but not the same event as the last one
                        if(Integer.parseInt(possibleEvent.getYear())== yearToBeat && !(possibleEvent.getType().toLowerCase().equals("birth")) && (possibleEvent.getEventID()!= mySortedList.get(currentIndex-1).getEventID()) ){

                        }
                    }
                    else{

                    }
                }
            }
        }


    return mySortedList;
    }
}
