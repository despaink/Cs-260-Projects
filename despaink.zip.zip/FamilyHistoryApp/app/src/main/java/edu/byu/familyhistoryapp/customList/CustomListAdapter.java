package edu.byu.familyhistoryapp.customList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import edu.byu.familyhistoryapp.R;
import model.Event;
import model.Model;
import model.Person;

public class CustomListAdapter extends BaseExpandableListAdapter {

    private Context context;
    private HashMap<String,List<String>> myLists;
    private Model myModel;

    public  CustomListAdapter(Context c, HashMap<String, List<String>> myData){
        context=c;
        myLists = myData;

        myModel= Model.getMyModel();
    }


    public String getMyChild(int groupPosition, int childPosition) {
       //then its the event group
        if(groupPosition ==0){
            return myLists.get("Events").get(childPosition);
        }
        else {
            return myLists.get("People").get(childPosition);

        }
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }



    @Override
    public View getChildView(int groupPosition, final int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {
        final String ID = getMyChild(groupPosition,childPosition);


        if(groupPosition ==0){
            final Event currEvent = myModel.myEventsByID.get(ID);
            final Person currPerson = myModel.allMyPeople.get(currEvent.getPersonID());

            //if(convertView == null){
                LayoutInflater layoutInflater = (LayoutInflater) this.context
                        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = layoutInflater.inflate(R.layout.list_item_event,null);
           // }
            TextView eventData = (TextView) convertView
                    .findViewById(R.id.eventData);
            eventData.setText(""+currEvent.getType()+": "+currEvent.getCity()+", "+currEvent.getCountry()+" ("+currEvent.getYear()+")");
            TextView personData = (TextView) convertView
                    .findViewById(R.id.personData);
            personData.setText(currPerson.getFirstName()+", "+currPerson.getLastName());
            return convertView;
        }
        else if(groupPosition ==1){
            final Person currPerson = myModel.allMyPeople.get(ID);



            //if(convertView == null){
                LayoutInflater layoutInflater = (LayoutInflater) this.context
                        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = layoutInflater.inflate(R.layout.list_item_person,null);
           // }
            TextView name = (TextView) convertView
                    .findViewById(R.id.Name_List);
            if(name!= null)
            name.setText(currPerson.getFirstName()+" "+currPerson.getLastName());
            TextView relation = (TextView) convertView
                    .findViewById(R.id.Relation_List);
            if(relation != null)
            relation.setText("Relative");

            return convertView;
        }
        return null;
    }

    @Override
    public int getChildrenCount(int groupPosition) {

        if(groupPosition == 0)
        {
            return myLists.get("Events").size();
        }
        else{
            return myLists.get("People").size();

        }

    }

    @Override
    public String getGroup(int groupPosition) {
        if(groupPosition==0){
            return "Events";
        }
        else {
            return "People";
        }
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return null;
    }

    @Override
    public int getGroupCount() {
        return 2;
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {

        if(convertView==null){
            LayoutInflater layoutInflater = (LayoutInflater) this.context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.list_group,null);
        }

        TextView listTitleTextView = (TextView) convertView
                .findViewById(R.id.listTitle);
        listTitleTextView.setText(getGroup(groupPosition));
        return convertView;
    }


    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}
