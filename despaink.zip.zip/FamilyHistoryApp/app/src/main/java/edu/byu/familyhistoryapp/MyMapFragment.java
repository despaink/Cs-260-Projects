package edu.byu.familyhistoryapp;

/*
GoogleMap map;
...
// Sets the map type to be "hybrid"
map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
*/


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import model.DataFile;
import model.Event;
import model.Model;
import model.Person;

import static android.widget.Toast.LENGTH_SHORT;

public class MyMapFragment extends Fragment implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener {

    public interface ContextOnLogOut {
        //void onProgressUpdate(int percent);
        //void onDownloadComplete(long totalBytes);
        void onLogout();
    }

    private ContextOnLogOut contextOnLogOut;

    private  static final int LOGOUT_CASE = 1;
    private  static final int RESYNC_CASE = 2;
    private  static final int RESYNC_CASE_FAIL = 3;



    private GoogleMap mMap;
    private SupportMapFragment mapFragment;
    private static Model myModel;

    private TextView personName_TV;
    private TextView eventData_TV;
    private ImageView genderIcon;
    private LinearLayout eventDataBox_LL;

   private LatLng currentLatLng;


    public  MyMapFragment newInstance(){
         myModel= Model.getMyModel();
         return new MyMapFragment();
    }
    public MyMapFragment(){}
    public MyMapFragment(ContextOnLogOut c){
        contextOnLogOut = c;
    }


    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.onCreateView(layoutInflater, viewGroup, bundle);
        View v = layoutInflater.inflate(R.layout.fragment_map, viewGroup, false);

        personName_TV = v.findViewById(R.id.personNameView);
        eventData_TV = v.findViewById(R.id.eventNameView);
        genderIcon = v.findViewById(R.id.imageViewGender);
        eventDataBox_LL= v.findViewById(R.id.EventDisplayMap);

        currentLatLng = new LatLng(-34, 151);

        Bundle b = getArguments();
        if(b.containsKey("EVENT_ID")){
            String eventID = b.getString("EVENT_ID");

            Event currEvent = myModel.myEventsByID.get(eventID);
            final Person currPerson = myModel.allMyPeople.get(currEvent.getPersonID());

            currentLatLng = new LatLng(Double.parseDouble(currEvent.getLattitude()),Double.parseDouble(currEvent.getLongitude()));


            personName_TV.setText(currPerson.getFirstName() +" "+currPerson.getLastName());
            eventData_TV.setText(currEvent.getType()+": " +currEvent.getCity()+ ", "+currEvent.getCountry()+" ("+currEvent.getYear()+")");
            eventDataBox_LL.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent(getContext(),PersonActivity.class);
                    intent.putExtra("PERSON_ID", currPerson.getPersonID());
                    startActivity(intent);



                }
            });

        }
        else{
            personName_TV.setText("Click on a marker");
            eventData_TV.setText("to see event details");
            setHasOptionsMenu(true);
        }







        mapFragment = (SupportMapFragment)getChildFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        return v;
    }

    @Override
    public void onResume() {
        super.onResume();


        mapFragment.getMapAsync(this);


        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
    super.onCreateOptionsMenu(menu,inflater);
    inflater.inflate(R.menu.menu,menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        Intent intent;
        switch (item.getItemId()){
            case R.id.search_item:
                Toast.makeText(getContext(),"Search Item",Toast.LENGTH_SHORT).show();

                return true;
            case R.id.filter_item:
                 intent = new Intent(getContext(),FilterActivity.class);
                startActivityForResult(intent,0);



                return true;
            case R.id.settings_item:
                 intent = new Intent(getContext(),SettingsActivity.class);
                startActivityForResult(intent,0);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }




    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        myModel = Model.getMyModel();
        markTheMap();
        // Add a marker in Sydney and move the camera

        mMap.moveCamera(CameraUpdateFactory.newLatLng(currentLatLng));

        mMap.setOnMarkerClickListener(this);

    }


    private void markTheMap( ){
        mMap.clear();
        myModel = Model.getMyModel();
        Set<String> myActivePeople = myModel.getActivePeople();
        Iterator<String> iterator = myActivePeople.iterator();
        HashMap<String, Marker> myMarkers= new HashMap<>();

        //for each person
        while(iterator.hasNext()){
            HashSet<Event> currEvents = myModel.getMyEventMapByPerson().get(iterator.next());
            Iterator<Event> currEvent = currEvents.iterator();

            // for each event belonging to that person
            while (currEvent.hasNext()){
                Event tempEvent = currEvent.next();
                /*
        LatLng sydney = new LatLng(-34, 151);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));*/
                if(myModel.filteredOptions.get(tempEvent.getType()).equals("true")){
                    LatLng tempLatLng = new LatLng(Double.parseDouble(tempEvent.getLattitude()),Double.parseDouble(tempEvent.getLongitude()));
                    Marker tempMarker = mMap.addMarker( new MarkerOptions()
                            .position(tempLatLng));
                    tempMarker.setTag(tempEvent.getEventID());

                    myMarkers.put(""+tempMarker.getTag(),tempMarker);
                }


            }


        }

    }

    @Override
    public boolean onMarkerClick(Marker marker) {

        //Toast.makeText(getContext(),""+marker.getTag()+"",Toast.LENGTH_SHORT).show();


        Event currEvent = myModel.myEventsByID.get(marker.getTag());
        final Person currPerson = myModel.allMyPeople.get(currEvent.getPersonID());

        personName_TV.setText(currPerson.getFirstName() +" "+currPerson.getLastName());
        eventData_TV.setText(currEvent.getType()+": " +currEvent.getCity()+ ", "+currEvent.getCountry()+" ("+currEvent.getYear()+")");


        eventDataBox_LL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getContext(),PersonActivity.class);
                intent.putExtra("PERSON_ID", currPerson.getPersonID());
                startActivity(intent);



            }
        });

        return false;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(data == null){
            return;
        }
        int myCase= data.getIntExtra("result_case",0);

        switch(myCase) {
            case LOGOUT_CASE:{
                contextOnLogOut.onLogout();
                break;
            }

            case RESYNC_CASE:{
                mapFragment.getMapAsync(this);
                personName_TV.setText("Click on a marker");
                eventData_TV.setText("to see event details");
                break;
            }
            case RESYNC_CASE_FAIL:{

                Intent intent = new Intent(getContext(),SettingsActivity.class);
                startActivityForResult(intent,0);
                break;
            }

             default:{
                Toast.makeText(getContext(),"A started activity did not return a result_case",Toast.LENGTH_LONG).show();
                break;
            }

        }

    }


        }
