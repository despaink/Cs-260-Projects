package edu.byu.familyhistoryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import model.Model;

class myListAdapter extends BaseAdapter {

    Model myModel;

    Context context;
    String[] data;
    private static LayoutInflater inflater = null;

    public myListAdapter(Context context, String[] data) {

        this.context = context;
        this.data = data;

        myModel = Model.getMyModel();

        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return data.length;
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return data[position];
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        View vi = convertView;
        if (vi == null)
            vi = inflater.inflate(R.layout.list_item, null);
        final TextView title = vi.findViewById(R.id.title_list);
        TextView caption = vi.findViewById(R.id.caption_list);
        Switch mySwitch = vi.findViewById(R.id.switch_list);

        title.setText(data[position]);
        caption.setText(("Filter by "+ data[position] +" Events").toUpperCase());
        if(myModel.filteredOptions.get(title.getText().toString())== null){
            myModel.filteredOptions.put(title.getText().toString(),"true");

        }

        if(myModel.filteredOptions.get(title.getText().toString()).equals("false")){
            mySwitch.setChecked(false);
        }
        else {
            mySwitch.setChecked(true);
        }

        mySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if(isChecked) {
                myModel.filteredOptions.put(title.getText().toString(),"true");
            }
            else {
                myModel.filteredOptions.put(title.getText().toString(),"false");
            }
                Toast.makeText(context, myModel.filteredOptions.get(title.getText().toString()),Toast.LENGTH_SHORT).show();
            }
        });
        return vi;
    }
}
