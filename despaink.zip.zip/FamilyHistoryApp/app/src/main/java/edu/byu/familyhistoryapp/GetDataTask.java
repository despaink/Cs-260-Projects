package edu.byu.familyhistoryapp;

import android.os.AsyncTask;

import model.DataFile;
import model.LoginResponse;
import serverProxy.Proxy;

public class GetDataTask extends AsyncTask<LoginResponse,String,DataFile> {

    public interface ContextGetData {
        void onGetDataComplete(DataFile myData);
    }

    private ContextGetData context;

    public GetDataTask(ContextGetData c){
        context = c;
    }

    @Override
    protected DataFile doInBackground(LoginResponse... responses) {
        Proxy proxy = new Proxy( "10.0.2.2","8080");
        return proxy.getData(responses[0].getAuthToken());
    }

    @Override
    protected void onPostExecute(DataFile s) {

        context.onGetDataComplete(s);

    }
}
