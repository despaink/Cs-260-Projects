package edu.byu.familyhistoryapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.TextView;
import android.widget.Toolbar;

import java.util.HashMap;
import java.util.List;

import edu.byu.familyhistoryapp.customList.CustomListDataPump;
import edu.byu.familyhistoryapp.customList.CustomListAdapter;
import model.Event;
import model.Model;
import model.Person;

import edu.byu.familyhistoryapp.customList.*;

public class PersonActivity extends AppCompatActivity {
    private Model myModel;
    private TextView firstName_TV;
    private TextView lastName_TV;
    private  TextView gender_TV;
    private TextView toolbar_title_TV;
    private Toolbar toolbar;

    private ExpandableListView expandableListView;
    private ExpandableListAdapter expandableListAdapter;
    private HashMap<String, List<String>> expandableListDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    String personID= getIntent().getStringExtra("PERSON_ID");

    setContentView(R.layout.person);
    myModel= Model.getMyModel();

    firstName_TV = findViewById(R.id.textViewFirstName);
    lastName_TV = findViewById(R.id.textViewLastName);
    gender_TV = findViewById(R.id.textViewGender);


    expandableListView = findViewById(R.id.expandableListView);
    expandableListDetail = CustomListDataPump.getMyData( personID);
    expandableListAdapter = new CustomListAdapter(this,expandableListDetail);

    expandableListView.setAdapter(expandableListAdapter);

    Person currPerson = myModel.allMyPeople.get(personID);

    if(currPerson != null){
        firstName_TV.setText(currPerson.getFirstName());
        lastName_TV.setText(currPerson.getLastName());

        if(currPerson.getGender().toLowerCase().equals("m")){
            gender_TV.setText("Male");

        }
        else {
            gender_TV.setText("Female");
        }

    }

    expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
        @Override
        public boolean onChildClick(ExpandableListView parent, View v,
                                    int groupPosition, int childPosition, long id) {

            String ID;
            if(groupPosition ==0){
                 ID = expandableListDetail.get("Events").get(childPosition);
                 Intent intent = new Intent(PersonActivity.this,EventActivity.class);
                 intent.putExtra("EVENT_ID",ID);
                 startActivity(intent);
            }
            else {
                ID = expandableListDetail.get("People").get(childPosition);
                Intent intent = new Intent(PersonActivity.this,PersonActivity.class);
                intent.putExtra("PERSON_ID", ID);
                startActivity(intent);

            }

            return false;
        }
    });


    }




    public static void startTopActivity(Context context, boolean newInstance) {
        Intent intent = new Intent(context, MainActivity.class);
        if (newInstance) {
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        }
        else {
            intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        }
        context.startActivity(intent);
    }
}
