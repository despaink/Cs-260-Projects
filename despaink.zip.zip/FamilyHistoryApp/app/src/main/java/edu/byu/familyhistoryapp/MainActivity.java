package edu.byu.familyhistoryapp;

import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import model.DataFile;
import model.Model;

import static model.Model.getMyModel;
import static model.Model.makeMyModel;



// google api key = AIzaSyBxyWEUxw_czFsQ-FWoXewlmqW5bWJjtZE

public class MainActivity extends AppCompatActivity implements LoginFragment.ContextOnGetData, MyMapFragment.ContextOnLogOut {

    private LoginFragment myLoginFragment;
    private MyMapFragment myMapFragment;
    private Model myModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentManager fm = this.getSupportFragmentManager();

        myModel = Model.getMyModel();

        //Toast.makeText(this,""+myModel.isLoggedIn()+"",Toast.LENGTH_LONG).show();

            myLoginFragment = (LoginFragment) fm.findFragmentById(R.id.currentFragment);
            if(myLoginFragment==null){
                myLoginFragment= new LoginFragment(this);
                fm.beginTransaction()
                        .add(R.id.currentFragment,myLoginFragment)
                        .commit();
            }



    }

    @Override
    public void onResume(){
        super.onResume();



    }




    @Override
    public void replaceFragments() {

        Bundle args = new Bundle();

        myMapFragment= new MyMapFragment(this);
        myMapFragment.setArguments(args);
        android.support.v4.app.FragmentTransaction t = getSupportFragmentManager().beginTransaction();
        t.replace(R.id.currentFragment, myMapFragment);
        t.commit();


    }


    @Override
    public void onGetData(DataFile myData) {
        myModel = makeMyModel(myData);
        myModel = getMyModel();

       // Toast.makeText(this,""+myModel.isLoggedIn()+"",Toast.LENGTH_LONG).show();
        //Toast.makeText(this, "Number of people: "+myModel.peopleNum()+" Size of Event Map: "+myModel.EventNum()+"",Toast.LENGTH_LONG).show();

        replaceFragments();

    }

    @Override
    public void onLogout() {
        myModel = Model.getMyModel();

        myLoginFragment = new LoginFragment(this);
        android.support.v4.app.FragmentTransaction t = getSupportFragmentManager().beginTransaction();
        t.replace(R.id.currentFragment, myLoginFragment);
        t.commit();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
    }

}
