package edu.byu.familyhistoryapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;

import com.google.android.gms.maps.MapFragment;

public class EventActivity extends AppCompatActivity {
    private MyMapFragment myMapFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String eventID= getIntent().getStringExtra("EVENT_ID");


        setContentView(R.layout.activity_event);

        FragmentManager fm = this.getSupportFragmentManager();

        Bundle args = new Bundle();
        args.putString("EVENT_ID", eventID);
        myMapFragment= new MyMapFragment();
        myMapFragment.setArguments(args);

        fm.beginTransaction()
                .add(R.id.currentFragment,myMapFragment)
                .commit();
    }



}
