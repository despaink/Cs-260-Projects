package edu.byu.familyhistoryapp;

import android.os.AsyncTask;

import model.DataFile;
import model.HostAndAuth;
import serverProxy.Proxy;

public class ResyncDataTask extends AsyncTask<HostAndAuth,String, DataFile> {

    public interface ContextGetData {
        void onGetDataComplete(DataFile myData);
    }

    private ContextGetData contextGetData;

    public ResyncDataTask(ContextGetData context){
        contextGetData=context;
    }

    @Override
    protected DataFile doInBackground(HostAndAuth... hostAndAuths) {

        Proxy proxy = new Proxy( "10.0.2.2","8080");
        return proxy.getData(hostAndAuths[0].getAuthToken());
    }

    @Override
    protected void onPostExecute(DataFile s) {

        contextGetData.onGetDataComplete(s);

    }

}
