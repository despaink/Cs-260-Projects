package edu.byu.familyhistoryapp;

import android.support.v7.app.AppCompatActivity;

public class SearchActivity extends AppCompatActivity {

}
