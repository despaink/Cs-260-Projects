package model;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;

public class Model {

    private static Model myModel;
    private boolean isLoggedIn;
    private String AuthToken;

    private String serverHost;
    private String serverPort;

    public HashMap<String,HashSet<Event>> MyEventMapByPerson;
    public HashMap<String,Event> myEventsByID;
    public HashMap<String,Person> allMyPeople = new HashMap<>();
    public HashSet<String> filterSetTypes;
    public HashMap<String,String> filteredOptions;

    public HashSet<String > fatherSide;
    public HashSet<String> motherSide;
    private Person myRootPerson;
    public HashSet<Marker> myMarkers;

    private Model(){ isLoggedIn =false;}
    private Model(DataFile myData){
        MyEventMapByPerson = new HashMap<>();
        myEventsByID = new HashMap<>();
        fatherSide = new HashSet<>();
        motherSide = new HashSet<>();
        filteredOptions = new HashMap<>();
        filterSetTypes = new HashSet<>();

        isLoggedIn = true;
        myRootPerson = myData.getMyPeople().getData().get(0);
        setAuthToken(myData.getAuthToken());
        setServerHost(myData.getServerHost());
        setServerPort(myData.getServerPort());

        populateEventData(myData.getMyEvents().getData());
        populatePeopleData(myData.getMyPeople().getData());


    }


    public static Model getMyModel(){
        if(myModel==null){
            myModel = new Model();
        }
        return myModel;
    }

    public static Model makeMyModel(DataFile myData){
        myModel = new Model(myData);
        return myModel;
    }

    public boolean isLoggedIn() {
        return isLoggedIn;
    }

    public int peopleNum(){
        return fatherSide.size()+motherSide.size();
    }

    public int EventNum(){
        return MyEventMapByPerson.size();
    }

    public Map<String, HashSet<Event>> getMyEventMapByPerson() {
        return MyEventMapByPerson;
    }

    private void populateEventData(ArrayList<Event> myEvents){
        int addedEvent = 0;
        int addedPerson = 0;
        for (int i = 0; i< myEvents.size(); i++){

            Event curr = myEvents.get(i);
            myEventsByID.put(curr.getEventID(),curr);
            String person = curr.getPersonID();
            //then atleast one event is in the set.
            if(MyEventMapByPerson.containsKey(person)){
                MyEventMapByPerson.get(person).add(curr);
                filterSetTypes.add(curr.getType().toLowerCase());
                addedEvent ++;
            }
            //then this is the first event for this person
            else{
                HashSet<Event> temp = new HashSet<>();
                temp.add(curr);
                MyEventMapByPerson.put(person,temp);
                filterSetTypes.add(curr.getType().toLowerCase());


                addedEvent++;
                addedPerson++;
            }

        }

        setUpFilterMap();
        //System.out.println( "Number of people: "+ addedPerson+" Number of Events: "+ addedEvent);


    }

    private void populatePeopleData(ArrayList<Person> myPeople){


        for(int i =0; i< myPeople.size();i++){
            allMyPeople.put(myPeople.get(i).getPersonID(), myPeople.get(i));
        }

        divideMyPeople();



    }

    private void divideMyPeople(){
        patriarch(myRootPerson.getFather());

        matriarch(myRootPerson.getMother());

    }
    private void patriarch(String head){
        Person curr= null;

        if(head == null){return;}

        if(allMyPeople.containsKey(head)) { curr = allMyPeople.get(head);}

        if(curr!= null) {

            if (curr.getFather() != null) {
                patriarch(curr.getFather());
                patriarch(curr.getMother());
            }


            fatherSide.add(head);
        }
    }

    private void matriarch(String head){

        if(head.isEmpty()){ return;}

        Person curr = allMyPeople.get(head);
        if(curr!= null) {

            if (curr.getFather() != null) {
                matriarch(curr.getFather());
                matriarch(curr.getMother());
            }


            motherSide.add(head);
        }
    }

    private void setUpFilterMap(){
        Iterator<String> iterator = filterSetTypes.iterator();

        while (iterator.hasNext()){
            filteredOptions.put(iterator.next(),"true");
        }

        filteredOptions.put("father","true");
        filteredOptions.put("mother","true");
        filteredOptions.put("male","true");
        filteredOptions.put("female","true");

    }


    public Set<String> getActivePeople(){
        HashSet<String> activePeople = new HashSet<>();

          //activePeople = MyEventMapByPerson.keySet();
        if(filteredOptions.get("father").equals("true")){
            activePeople.addAll( fatherSide);
        }
        if(filteredOptions.get("mother").equals("true")){
            activePeople.addAll(motherSide);
        }
        activePeople.add(myRootPerson.getPersonID());

        return activePeople;
    }

    public void setLoggedIn(boolean loggedIn) {
        isLoggedIn = loggedIn;
    }

    public String getAuthToken() {
        return AuthToken;
    }

    private void setAuthToken(String newAuthToken){
        AuthToken = newAuthToken;
    }

    public String getServerHost() {
        return serverHost;
    }

    public String getServerPort() {
        return serverPort;
    }

    public void setServerHost(String serverHost) {
        this.serverHost = serverHost;
    }

    public void setServerPort(String serverPort) {
        this.serverPort = serverPort;
    }

    public void changeFilterOptions(String key, String value){
        filteredOptions.put(key,value);
    }
    public String checkFilterOptions(String key){
        return  filteredOptions.get(key);
    }

}
