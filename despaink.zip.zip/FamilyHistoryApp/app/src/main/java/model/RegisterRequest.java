package model;

public class RegisterRequest {

    public RegisterRequest( String name, String pass, String mail, String first, String last, String g){
        userName = name;
        password = pass;
        email = mail;
        firstName = first;
        lastName = last;
        gender = g;
    }

    private String userName;
    private String password;
    private String email;
    private String firstName;
    private String lastName;
    private String gender;
}
