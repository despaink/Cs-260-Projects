package model;

public class HostAndAuth {
    private String authToken;
    private String serverHost;
    private String serverPort;

    public HostAndAuth(String auth, String host, String port){

        authToken=auth;
        serverHost=host;
        serverPort=port;
    }


    public String getAuthToken() {
        return authToken;
    }

    public String getServerHost() {
        return serverHost;
    }

    public String getServerPort() {
        return serverPort;
    }
}
