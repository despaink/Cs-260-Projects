package model;

public class LoginRequest {
    public LoginRequest(String name, String pass){
        userName = name;
        password = pass;
    }

    String userName;
    String password;
}
