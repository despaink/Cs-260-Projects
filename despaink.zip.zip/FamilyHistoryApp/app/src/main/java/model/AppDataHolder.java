package model;

public class AppDataHolder {
}
