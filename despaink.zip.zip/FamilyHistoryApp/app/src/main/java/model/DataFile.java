package model;

public class DataFile {

    private PersonFile myPeople;
    private EventFile myEvents;
    private String AuthToken;
    private String serverHost;
    private String serverPort;
    public String message;

    public DataFile(){}
    public DataFile(PersonFile myPeoples,EventFile myEventes, HostAndAuth hostAndAuth){
        myPeople = myPeoples;
        myEvents = myEventes;
        AuthToken = hostAndAuth.getAuthToken();
        serverHost = hostAndAuth.getServerHost();
        serverPort = hostAndAuth.getServerPort();
    }
    public DataFile(String messageIn){
        message=messageIn;
    }

    public PersonFile getMyPeople() {
        return myPeople;
    }

    public EventFile getMyEvents() {
        return myEvents;
    }

    public String getAuthToken() {
        return AuthToken;
    }

    public String getServerHost() {
        return serverHost;
    }

    public String getServerPort() {
        return serverPort;
    }

    public String getMessage(){return message;}
}
