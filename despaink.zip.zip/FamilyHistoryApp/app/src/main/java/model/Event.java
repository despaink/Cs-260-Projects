package model;

import java.sql.Connection;
import java.util.UUID;

public class Event {
    /**
     * given a user and a person,
     * generates a new event(pushing to database will occur in EventDAO)
     **/

    public Event(){}


    private String eventType;
    private String personID;
    private String country;
    private String city;
    private String latitude;
    private String longitude;
    private String year;
    private String eventID;
    private String descendant;


    public String getEventID() {
        return eventID;
    }

    public void setEventID(String eventID) {
        this.eventID = eventID;
    }

    public String getDecendant() {
        return descendant;
    }

    public void setDecendant(String decendant) {
        this.descendant = decendant;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getLattitude() {
        return latitude;
    }

    public void setLattitude(String lattitude) {
        this.latitude = lattitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getType() {
        return eventType;
    }

    public void setType(String type) {
        this.eventType = type;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
}


