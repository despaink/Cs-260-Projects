package serverProxy;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.UUID;

import model.LoginRequest;
import model.LoginResponse;
import model.RegisterRequest;

import static org.junit.Assert.*;

public class ProxyTest {

    // I'm assuming my server needs to be running to test these things.
    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testLogin(){
        Proxy myProxy = new Proxy("localhost","8080");

        RegisterRequest myRequest1 = new RegisterRequest("username","password","kdwspain","kendall","despain","m");


        LoginRequest myRequest = new LoginRequest("username","password");

        myProxy.register(myRequest1);

        assertNull(myProxy.login(myRequest).getMessage());
    }
    @Test
    public void testBadLogin(){
        Proxy myProxy = new Proxy("localhost","8080");

        LoginRequest myRequest = new LoginRequest("sername","password");

       assertNotNull(myProxy.login(myRequest).getMessage());

    }

    @Test
    public void testRegister(){
        Proxy myProxy = new Proxy("localhost","8080");
//UUID.randomUUID().toString()
        RegisterRequest myRequest = new RegisterRequest(UUID.randomUUID().toString(),"secret","kdwspain","kendall","despain","m");

        assertNull( myProxy.register(myRequest).getMessage());


    }

    @Test
    public void testBadRegister(){
        Proxy myProxy = new Proxy("localhost","8080");

        RegisterRequest myRequest = new RegisterRequest("meh","secret","kdwspain","kendall","despain","m");

        myProxy.register(myRequest);
        assertNotNull(myProxy.register(myRequest).getMessage());


    }

    @Test
    public void testGetData(){

        Proxy myProxy = new Proxy("localhost","8080");

        //just in case its not there I'm registering it.

        RegisterRequest myRequest1 = new RegisterRequest("despaink","password","kdwspain","kendall","despain","m");

        myProxy.register(myRequest1);

        LoginRequest myRequest = new LoginRequest("despaink","password");

        LoginResponse myResponse = myProxy.login(myRequest);

        assertNotNull(myProxy.getData(myResponse.getAuthToken()));
    }
    @Test
    public void testBadGetData(){

        Proxy myProxy = new Proxy("localhost","8080");

        LoginRequest myRequest = new LoginRequest("despaink","passwor");

        LoginResponse myResponse = myProxy.login(myRequest);

        assertNull(myProxy.getData(myResponse.getAuthToken()).message);
    }
}